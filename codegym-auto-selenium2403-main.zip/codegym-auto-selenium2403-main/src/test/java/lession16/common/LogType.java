package lession16.common;

public enum LogType {
    INFO,
    STEP,
    VERIFY,
    DEBUG
}
