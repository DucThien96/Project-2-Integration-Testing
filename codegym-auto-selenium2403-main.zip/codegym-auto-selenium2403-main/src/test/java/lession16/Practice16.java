package lession16;

/**
 * https://james.codegym.vn/mod/assign/view.php?id=18164
 */
public class Practice16 {
}
