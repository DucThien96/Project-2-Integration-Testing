package lession14.common;

public enum LogType {
    INFO,
    STEP,
    VERIFY,
    DEBUG
}
