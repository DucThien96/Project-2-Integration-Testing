package lession13.common;

public enum LogType {
    INFO,
    STEP,
    VERIFY,
    DEBUG
}
