### BÀI THỰC HÀNH 01

# 1. Nội dung 
1. Thực hiện tạo chương trình record 05 kịch bản kiểm thử khác nhau trên link: https://demoqa.com/elements

# 2. Yêu cầu
   1. Commit Code tại Git theo branch name học viên: 
   2. Deadline: 
