package lession15.common;

public enum LogType {
    INFO,
    STEP,
    VERIFY,
    DEBUG
}
