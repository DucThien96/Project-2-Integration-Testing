# Automation Test - Selenium Framework
## Info:
- Trainer: Vincent (083.286.8822 - giaduy218@gmail.com)
- Course's Syllabus: 16 lessons (Basic to Advance)
- Method: Offline


## Syllabus Detail
1. Tổng quan Selenium
2. Locator cơ bản
3. Locator nâng cao
4. Phương pháp tối ưu locator
5. Thực hành 01
6. Tương tác với các element cơ bản
7. WebDriver API Nâng cao & Action
8. Wait & JavaScript trong Automation
9. TestNG Framework
10. Luyện tập 02
11. Automation Web Framework 01
12. Automation Web Framework 02
13. Thực hành xây dựng Framework & Phát triển kịch bản kiểm thử - P1
14. Thực hành xây dựng Framework & Phát triển kịch bản kiểm thử - P2
15. Thực hành xây dựng Framework & Phát triển kịch bản kiểm thử - P3
16. Hoàn thiện Framework & Bài tập lớn
17. Luyện tập 03
18. Automation Web Framework (Cucumber) - Option
19. Kiểm tra